import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from tqdm import tqdm

# 加载原始数据
print("Step 1: loading data")
data = pd.read_csv("ContractWard-SimplifiedData.csv")
id_list = data['id'].tolist()
contract_list = data['contractAddr']
opcodes_list = data['opcode'].tolist()
label_list = data['label'].tolist()



# 构建2-gram模型，抽取相应的特征
print("Step 2: build 2-gram model")
opcodes = ['start '+item+' end' for item in opcodes_list]
counter = CountVectorizer( ngram_range=(2, 2))
counter.fit_transform(opcodes)
print(counter)

# 获取所有的特征名称
print("Step 3: obtain feature names")
featNames = ','.join(counter.get_feature_names())
print(featNames)


head = "id,contractAddr,label"
output_file = open("ContractWard-data.csv","w+")
output_file.write(head+","+featNames+"\n")


for idx, contractAddr in tqdm(enumerate(contract_list)):
    
    target_str = str(id_list[idx])+","+str(contractAddr)+","+str(label_list[idx])+","

    results = counter.transform([opcodes_list[idx]]).toarray()

    target_str += ','.join([str(it) for it in results.flatten().tolist()])+'\n'
    output_file.write(target_str)

    if idx % 1000 ==0:
        print("finish %s"%idx)
        output_file.flush()
        
    
output_file.flush()
output_file.close()
print("Finished!")
