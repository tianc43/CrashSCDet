import json
import solcx
import pandas as pd
import time, os, sys
from tqdm import tqdm


if __name__ == '__main__':
      
    
    instruction2simplified ={
            "ADD":"ARITHMETIC_OP",
            "MUL":"ARITHMETIC_OP", 
            "SUB":"ARITHMETIC_OP",
            "DIV":"ARITHMETIC_OP", 
            "SDIV":"ARITHMETIC_OP", 
            "SMOD":"ARITHMETIC_OP",
            "MOD":"ARITHMETIC_OP",
            "ADDMOD":"ARITHMETIC_OP",
            "MULMOD":"ARITHMETIC_OP", 
            "EXP":"ARITHMETIC_OP",

          
            
            "BLOCKHASH":"CONSTANT1",
            "COINBASE":"CONSTANT1",
            "TIMESTAMP":"CONSTANT1", 
            "NUMBER":"CONSTANT1",
            "DIFFICULTY":"CONSTANT1", 
            "GASLIMIT":"CONSTANT1", 
           

            "ADDRESS": "CONSTANT2",
            "BALANCE" : "CONSTANT2",
            "SELFBALANCE": "CONSTANT2",
            "ORIGIN" : "CONSTANT2",
            "CALLER": "CONSTANT2",
            "CALLVALUE": "CONSTANT2",
            "CALLDATALOAD": "CONSTANT2",
            "CALLDATASIZE": "CONSTANT2",
            "CALLDATACOPY": "CONSTANT2",
            "CODESIZE": "CONSTANT2",
            "CODECOPY": "CONSTANT2",
            "GASPRICE": "CONSTANT2",
            "EXTCODESIZE": "CONSTANT2",
            "EXTCODECOPY": "CONSTANT2",
            "RETURNDATASIZE": "CONSTANT2",
            "RETURNDATACOPY": "CONSTANT2",
            "CHAINID": "CONSTANT2",     
            "BASEFEE": "CONSTANT2",       
            
                        


            "LT" : "COMPARISON",
            "GT" : "COMPARISON",
            "SLT" : "COMPARISON",
            "SGT" : "COMPARISON",
            "EQ": "COMPARISON",
            "ISZERO": "COMPARISON",


            "AND" : "LOGIC_OP",
            "OR" : "LOGIC_OP",
            "XOR" : "LOGIC_OP",
            "NOT": "LOGIC_OP",
            "BYTE": "LOGIC_OP",

            "POP" : "STACK_MEM_STO_FLO",
            "MLOAD": "STACK_MEM_STO_FLO",
            "MSTORE": "STACK_MEM_STO_FLO",
            "MSTORE8": "STACK_MEM_STO_FLO",
            "SLOAD": "STACK_MEM_STO_FLO",
            "SSTORE": "STACK_MEM_STO_FLO",
            "JUMP": "STACK_MEM_STO_FLO",
            "JUMPI" : "STACK_MEM_STO_FLO",           
            "PC": "STACK_MEM_STO_FLO",
            "MSIZE": "STACK_MEM_STO_FLO",
            "GAS": "STACK_MEM_STO_FLO",
            "JUMPDEST": "STACK_MEM_STO_FLO",
            


            "CREATE" : "SYSTEM_OP",
            "CALL": "SYSTEM_OP",
            "CALLCODE": "SYSTEM_OP",
            "RETURN": "SYSTEM_OP",
            "DELEGATECALL": "SYSTEM_OP",
            "CREATE2": "SYSTEM_OP",
            "STATICCALL": "SYSTEM_OP",
            "REVERT": "SYSTEM_OP",
            "SELFDESTRUCT": "SYSTEM_OP",
            "STOP": "SYSTEM_OP",
            "SIGNEXTEND": "SYSTEM_OP",





            

            "DUP1" :"DUP",
            "DUP2":"DUP",
            "DUP3":"DUP",
            "DUP4":"DUP",
            "DUP5":"DUP",
            "DUP6":"DUP",
            "DUP7":"DUP",
            "DUP8":"DUP",
            "DUP9":"DUP",
            "DUP10":"DUP",
            "DUP11":"DUP",
            "DUP12":"DUP",
            "DUP13":"DUP",
            "DUP14":"DUP",
            "DUP15":"DUP",
            "DUP16":"DUP",

            "SWAP1":"SWAP",
            "SWAP2":"SWAP",
            "SWAP3":"SWAP",
            "SWAP4":"SWAP",
            "SWAP5":"SWAP",
            "SWAP6":"SWAP",
            "SWAP7":"SWAP",
            "SWAP8":"SWAP",
            "SWAP9":"SWAP",
            "SWAP10":"SWAP",
            "SWAP11":"SWAP",
            "SWAP12":"SWAP",
            "SWAP13":"SWAP",
            "SWAP14":"SWAP",
            "SWAP15":"SWAP",
            "SWAP16":"SWAP",

            "PUSH1":"PUSH",
            "PUSH2":"PUSH",
            "PUSH3":"PUSH",
            "PUSH4":"PUSH",
            "PUSH5":"PUSH",
            "PUSH6":"PUSH",
            "PUSH7":"PUSH",
            "PUSH8":"PUSH",
            "PUSH9":"PUSH",
            "PUSH10":"PUSH",
            "PUSH11":"PUSH",
            "PUSH12":"PUSH",
            "PUSH13":"PUSH",
            "PUSH14":"PUSH",
            "PUSH15":"PUSH",
            "PUSH16":"PUSH",
            "PUSH17":"PUSH",
            "PUSH18":"PUSH",
            "PUSH19":"PUSH",
            "PUSH20":"PUSH",
            "PUSH21":"PUSH",
            "PUSH22":"PUSH",
            "PUSH23":"PUSH",
            "PUSH24":"PUSH",
            "PUSH25":"PUSH",
            "PUSH26":"PUSH",
            "PUSH27":"PUSH",
            "PUSH28":"PUSH",
            "PUSH29":"PUSH",
            "PUSH30":"PUSH",
            "PUSH31":"PUSH",
            "PUSH32":"PUSH",

            "LOG0":"LOG",
            "LOG1":"LOG",
            "LOG2":"LOG",
            "LOG3":"LOG",
            "LOG4":"LOG",
        }

      
    opcodeinstruction = pd.read_csv("/data1/chaoni/caoxi-backup/smart-contact-materials/sc_major_revision/ObtainByteCode/opcodeinstruction.csv")
    opcode2instruction = dict(zip(opcodeinstruction['opcode'],opcodeinstruction['instruction']))


    head = "id,contractAddr,opcode,label"

    output_file = open("ContractWard-SimplifiedData.csv","w+")
    output_file.write(head+"\n")

    # all used smart contract
    data = pd.read_csv("/data1/chaoni/caoxi-backup/smart-contact-materials/sc_major_revision/Safe-SmartContracts/input_data/safe-data.csv")

    id_lists = data['id'].tolist()
    contractAddr_list = data['contractAddr'].tolist()
    opcode_list = data['opcode'].tolist()
    label_list = data['label'].tolist()
    
    for idx, contractAddr in enumerate(contractAddr_list):
        print("Current: %s"%idx )
        try:
            # print(row['id'], row['contractAddr'], row['opcode'],row['label'])
            instrs_list = [ instruction2simplified.get(opcode2instruction[item], "OTHER") for item in opcode_list[idx].split(' ')]
            result_str = ' '.join(instrs_list)
            output_file.write(str(id_lists[idx])+ ","+ str(contractAddr)+ ","+ result_str + ","+ str(label_list[idx])+"\n")
            
            if idx  % 1000 == 0:
                output_file.flush()
                
        except Exception as e:
            print("error:", idx) 
            break

    output_file.flush()
    output_file.close()

    print('Finished')




    
